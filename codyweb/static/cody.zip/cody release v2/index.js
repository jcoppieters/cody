//
// Johan Coppieters - jan 2013 - Cody CMS
//
//

var express = require('express');
var cody = require('./cody');

cody.server = express();

// cookies are encrypted, so we need a pass phrase
cody.server.use(express.bodyParser());
cody.server.use(express.cookieParser("a secret"));
cody.server.use(express.cookieSession());


// startup a routing for all static content of cody (images, javascript, css)
cody.server.get("/cody/static/*", function (req, res) {
    var fileserver = new cody.Static(req, res, "");
    fileserver.serve();
});


cody.startWebApp(cody.server, {
        "name": "mysite",
        "version": "v1.0a1",
        "defaultlanguage": "en",
        "hostnames" : "test.mysite.com,mysite.local",
        "dbuser": "cody",
        "dbpassword": "ydoc",
        "dbhost": "localhost",
        "datapath": "/usr/local/data/mysite",
        "db": "mysite",
        "controllers": require("./mysite/controllers/")
    }, function() {
  console.log("Loaded mysite....");

  cody.server.listen(3001);
  console.log('Listening on port 3001');
});
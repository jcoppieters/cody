version 1.0a2

for documentation see http://howest.cody-cms.org

contact us at johan.coppieters@howest.be

The Cody team.

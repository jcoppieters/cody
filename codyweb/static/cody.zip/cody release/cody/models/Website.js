//
// Johan Coppieters - may 2013 - cody
//
//
console.log("loading " + module.id);

var cody = require("../index.js");
